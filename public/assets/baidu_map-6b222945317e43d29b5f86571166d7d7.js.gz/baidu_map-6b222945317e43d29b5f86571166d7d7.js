  <script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=18c0ce1c33da6654d1254002ee91e00f"></script>
  <style type="text/css">
    body, html {width: 100%;height: 100%;margin:0;font-family:"微软雅黑";font-family:"微软雅黑";}
    #allmap{width:400px;height:200px;}
    p{margin-left:5px; font-size:14px;}
    #r-result{width:100%;}
  </style>
;
